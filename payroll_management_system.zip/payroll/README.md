# 💼 PayrollPro – Payroll Management System

> **Tech Stack:** React.js + Node.js + Express + MySQL (InfinityFree) + Google Charts

---

## 📁 Project Structure

```
payroll/
├── backend/                  ← Node.js + Express API
│   ├── config/db.js          ← MySQL connection (InfinityFree)
│   ├── routes/
│   │   ├── employees.js      ← Employee CRUD
│   │   ├── payroll.js        ← Payroll generation + PDF slips
│   │   ├── departments.js    ← Department management
│   │   └── taxSettings.js    ← Tax rules management
│   ├── server.js             ← Main server
│   ├── .env                  ← Your DB credentials (already filled)
│   └── package.json
├── frontend/                 ← React.js UI
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Dashboard.js  ← Stats + Google Charts
│   │   │   ├── Employees.js  ← Employee management
│   │   │   ├── Payroll.js    ← Generate payroll + PDF download
│   │   │   ├── Reports.js    ← Monthly/Annual charts
│   │   │   ├── Departments.js
│   │   │   └── TaxSettings.js
│   │   ├── utils/api.js      ← Axios API calls
│   │   ├── App.js            ← Router + Layout
│   │   └── App.css           ← Full dark theme styles
│   └── package.json
└── database_setup.sql        ← Run this in InfinityFree phpMyAdmin
```

---

## 🗄️ STEP 1: Setup Database (InfinityFree)

1. Log in to **dash.infinityfree.com**
2. Go to your hosting account → **MySQL Databases**
3. Create a database named: `if0_42116340_payroll`
4. Open **phpMyAdmin** for that database
5. Click **SQL** tab
6. Copy ALL contents from `database_setup.sql` and paste → click **Go**

✅ This creates all 4 tables + sample data automatically.

---

## ⚙️ STEP 2: Setup Backend

```bash
cd payroll/backend
npm install
```

The `.env` file is already configured with your InfinityFree credentials:
```
DB_HOST=sql.infinityfree.com
DB_USER=if0_42116340
DB_PASSWORD=lnWDrsPyYY3M
DB_NAME=if0_42116340_payroll
```

> ⚠️ **Note:** InfinityFree free plan has limited external MySQL access.
> If you get connection errors, you may need to:
> - Use the backend on a local machine or a VPS
> - OR use InfinityFree's built-in PHP backend instead

**Start the backend:**
```bash
npm start
# Server runs on http://localhost:5000
```

Test it: open http://localhost:5000/api/health

---

## 🎨 STEP 3: Setup Frontend

```bash
cd payroll/frontend
npm install
npm start
# Opens http://localhost:3000
```

---

## 🌐 STEP 4: Deploy to InfinityFree

### Backend (Node.js)
InfinityFree does NOT support Node.js. Options:
1. **Render.com** (free) — deploy Node.js backend there
2. **Railway.app** (free tier) — drag and drop deploy
3. **Cyclic.sh** — free Node.js hosting

After deploying backend, update frontend `.env`:
```
REACT_APP_API_URL=https://your-backend.render.com/api
```

### Frontend (React)
```bash
cd frontend
npm run build
```
Upload the `build/` folder contents to InfinityFree's `htdocs/` folder via FileZilla FTP.

---

## ✨ Features Implemented

| Feature | Status |
|---------|--------|
| Employee Profile Management | ✅ |
| Department Management | ✅ |
| Automatic Salary Calculation (Basic + HRA + DA + TA + MA) | ✅ |
| Tax Computation (PT, SS, Income Tax slabs) | ✅ |
| Generate Downloadable PDF Payslips | ✅ |
| Monthly/Annual Payroll Reports with **Google Charts** | ✅ |
| Payment Status Tracking | ✅ |
| Search & Filter Employees | ✅ |
| Responsive Dark UI | ✅ |

---

## 📊 Salary Calculation Formula

```
Gross Salary = Base + HRA (40% of Base) + DA (20% of Base) + TA (₹1600) + MA (₹1250)
PT Deduction  = 2% of Gross
SS Deduction  = 1.75% of Gross
IT Deduction  = Income Tax slab on Annual Gross / 12
Total Deductions = PT + SS + IT
Net Salary = Gross - Total Deductions
```

---

## 🔧 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/dashboard | Dashboard stats |
| GET | /api/employees | List all employees |
| POST | /api/employees | Create employee |
| PUT | /api/employees/:id | Update employee |
| DELETE | /api/employees/:id | Delete employee |
| GET | /api/payroll | List payroll records |
| POST | /api/payroll/generate | Generate monthly payroll |
| GET | /api/payroll/:id/slip | Download PDF payslip |
| PATCH | /api/payroll/:id/status | Update payment status |
| GET | /api/payroll/reports/summary | Charts data |
| GET | /api/departments | List departments |
| POST | /api/departments | Create department |
| GET | /api/tax-settings | List tax rules |
| POST | /api/tax-settings | Create tax rule |

---

## 🛠 Tech Clarification

Your instructor said "Google Antigravity tool" — this does NOT exist.
This project uses **Google Charts** (charts.googleapis.com), which is likely what was meant.
Google Charts provides:
- Line charts for monthly payroll trends
- Column charts for monthly payouts
- Pie charts for department breakdown
- Stacked bar charts for tax analysis
