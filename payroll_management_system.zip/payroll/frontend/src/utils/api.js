import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

// Request interceptor
api.interceptors.request.use(
  config => config,
  error => Promise.reject(error)
);

// Response interceptor
api.interceptors.response.use(
  response => response.data,
  error => {
    const message = error.response?.data?.message || error.message || 'Something went wrong';
    return Promise.reject(new Error(message));
  }
);

// Employees
export const employeeAPI = {
  getAll: (params) => api.get('/employees', { params }),
  getById: (id) => api.get(`/employees/${id}`),
  create: (data) => api.post('/employees', data),
  update: (id, data) => api.put(`/employees/${id}`, data),
  delete: (id) => api.delete(`/employees/${id}`)
};

// Payroll
export const payrollAPI = {
  getAll: (params) => api.get('/payroll', { params }),
  generate: (data) => api.post('/payroll/generate', data),
  updateStatus: (id, data) => api.patch(`/payroll/${id}/status`, data),
  getSlipUrl: (id) => `${process.env.REACT_APP_API_URL || 'http://localhost:5000/api'}/payroll/${id}/slip`,
  getReports: (params) => api.get('/payroll/reports/summary', { params })
};

// Departments
export const departmentAPI = {
  getAll: () => api.get('/departments'),
  create: (data) => api.post('/departments', data),
  update: (id, data) => api.put(`/departments/${id}`, data),
  delete: (id) => api.delete(`/departments/${id}`)
};

// Tax Settings
export const taxAPI = {
  getAll: () => api.get('/tax-settings'),
  create: (data) => api.post('/tax-settings', data),
  update: (id, data) => api.put(`/tax-settings/${id}`, data),
  delete: (id) => api.delete(`/tax-settings/${id}`)
};

// Dashboard
export const dashboardAPI = {
  getStats: () => api.get('/dashboard')
};

export default api;
