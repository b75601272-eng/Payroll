-- ============================================================
-- PAYROLL MANAGEMENT SYSTEM - MySQL Schema
-- Run this in InfinityFree phpMyAdmin
-- ============================================================

-- Departments table
CREATE TABLE IF NOT EXISTS departments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default departments
INSERT INTO departments (name) VALUES 
  ('Engineering'),
  ('Marketing'),
  ('Human Resources'),
  ('Finance'),
  ('Operations');

-- Tax settings table
CREATE TABLE IF NOT EXISTS tax_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  tax_type ENUM('PT','SS','IT','OTHER') NOT NULL,
  rate DECIMAL(5,2) NOT NULL COMMENT 'Percentage rate',
  min_salary DECIMAL(12,2) DEFAULT 0,
  max_salary DECIMAL(12,2) DEFAULT NULL COMMENT 'NULL means no upper limit',
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default tax settings
INSERT INTO tax_settings (name, tax_type, rate, min_salary, max_salary) VALUES
  ('Professional Tax', 'PT', 2.00, 10000.00, NULL),
  ('Social Security', 'SS', 1.75, 0.00, NULL),
  ('Income Tax (0%)', 'IT', 0.00, 0.00, 250000.00),
  ('Income Tax (5%)', 'IT', 5.00, 250001.00, 500000.00),
  ('Income Tax (10%)', 'IT', 10.00, 500001.00, 750000.00),
  ('Income Tax (15%)', 'IT', 15.00, 750001.00, 1000000.00),
  ('Income Tax (20%)', 'IT', 20.00, 1000001.00, NULL);

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  phone VARCHAR(20),
  department_id INT,
  designation VARCHAR(100),
  base_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  hra_percent DECIMAL(5,2) DEFAULT 40.00 COMMENT 'HRA as % of base salary',
  da_percent DECIMAL(5,2) DEFAULT 20.00 COMMENT 'DA as % of base salary',
  ta_fixed DECIMAL(10,2) DEFAULT 1600.00 COMMENT 'Travel Allowance fixed amount',
  ma_fixed DECIMAL(10,2) DEFAULT 1250.00 COMMENT 'Medical Allowance fixed amount',
  joining_date DATE NOT NULL,
  status ENUM('active','inactive','terminated') DEFAULT 'active',
  bank_account VARCHAR(30),
  bank_name VARCHAR(100),
  pan_number VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Payroll records table
CREATE TABLE IF NOT EXISTS payroll_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  month INT NOT NULL COMMENT '1-12',
  year INT NOT NULL,
  base_salary DECIMAL(12,2) NOT NULL,
  hra DECIMAL(12,2) DEFAULT 0.00,
  da DECIMAL(12,2) DEFAULT 0.00,
  ta DECIMAL(12,2) DEFAULT 0.00,
  ma DECIMAL(12,2) DEFAULT 0.00,
  other_allowances DECIMAL(12,2) DEFAULT 0.00,
  gross_salary DECIMAL(12,2) NOT NULL,
  pt_deduction DECIMAL(10,2) DEFAULT 0.00,
  ss_deduction DECIMAL(10,2) DEFAULT 0.00,
  it_deduction DECIMAL(10,2) DEFAULT 0.00,
  other_deductions DECIMAL(10,2) DEFAULT 0.00,
  total_deductions DECIMAL(12,2) DEFAULT 0.00,
  net_salary DECIMAL(12,2) NOT NULL,
  payment_status ENUM('pending','paid','failed') DEFAULT 'pending',
  payment_date DATE,
  generated_by VARCHAR(100),
  remarks TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  UNIQUE KEY unique_payroll (employee_id, month, year)
);

-- Sample employees
INSERT INTO employees (employee_id, name, email, phone, department_id, designation, base_salary, joining_date) VALUES
  ('EMP001', 'Rahul Sharma', 'rahul.sharma@company.com', '9876543210', 1, 'Software Engineer', 65000.00, '2023-01-15'),
  ('EMP002', 'Priya Patel', 'priya.patel@company.com', '9876543211', 2, 'Marketing Manager', 55000.00, '2022-06-01'),
  ('EMP003', 'Amit Kumar', 'amit.kumar@company.com', '9876543212', 4, 'Accountant', 45000.00, '2021-09-10'),
  ('EMP004', 'Sunita Reddy', 'sunita.reddy@company.com', '9876543213', 3, 'HR Executive', 40000.00, '2023-03-20'),
  ('EMP005', 'Vikram Singh', 'vikram.singh@company.com', '9876543214', 1, 'Senior Developer', 85000.00, '2020-11-05');

-- View for payroll summary
CREATE OR REPLACE VIEW payroll_summary AS
SELECT 
  pr.id,
  pr.month,
  pr.year,
  e.employee_id as emp_code,
  e.name as employee_name,
  d.name as department,
  e.designation,
  pr.gross_salary,
  pr.total_deductions,
  pr.net_salary,
  pr.payment_status,
  pr.payment_date
FROM payroll_records pr
JOIN employees e ON pr.employee_id = e.id
LEFT JOIN departments d ON e.department_id = d.id;
