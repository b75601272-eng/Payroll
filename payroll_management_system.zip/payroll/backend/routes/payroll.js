const express = require('express');
const router = express.Router();
const db = require('../config/db');
const PDFDocument = require('pdfkit');

// Helper: Calculate tax
function calculateTax(grossSalary, taxSettings) {
  let ptDeduction = 0, ssDeduction = 0, itDeduction = 0;
  const annualSalary = grossSalary * 12;

  taxSettings.forEach(tax => {
    if (!tax.is_active) return;
    const rate = parseFloat(tax.rate) / 100;

    if (tax.tax_type === 'PT') {
      if (grossSalary >= parseFloat(tax.min_salary || 0)) {
        ptDeduction += grossSalary * rate;
      }
    } else if (tax.tax_type === 'SS') {
      ssDeduction += grossSalary * rate;
    } else if (tax.tax_type === 'IT') {
      const min = parseFloat(tax.min_salary || 0);
      const max = tax.max_salary ? parseFloat(tax.max_salary) : Infinity;
      if (annualSalary > min) {
        const taxableAmount = Math.min(annualSalary, max) - min;
        itDeduction += (taxableAmount * rate) / 12;
      }
    }
  });

  return {
    pt: Math.round(ptDeduction * 100) / 100,
    ss: Math.round(ssDeduction * 100) / 100,
    it: Math.round(itDeduction * 100) / 100
  };
}

// GET all payroll records
router.get('/', async (req, res) => {
  try {
    const { month, year, employee_id, status } = req.query;
    let query = `
      SELECT pr.*, e.name as employee_name, e.employee_id as emp_code, 
             d.name as department_name, e.designation
      FROM payroll_records pr
      JOIN employees e ON pr.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE 1=1
    `;
    const params = [];

    if (month) { query += ' AND pr.month = ?'; params.push(month); }
    if (year) { query += ' AND pr.year = ?'; params.push(year); }
    if (employee_id) { query += ' AND pr.employee_id = ?'; params.push(employee_id); }
    if (status) { query += ' AND pr.payment_status = ?'; params.push(status); }
    query += ' ORDER BY pr.year DESC, pr.month DESC, e.name ASC';

    const [rows] = await db.query(query, params);
    res.json({ success: true, data: rows, count: rows.length });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST generate payroll for a month
router.post('/generate', async (req, res) => {
  try {
    const { month, year, employee_ids } = req.body;
    if (!month || !year) {
      return res.status(400).json({ success: false, message: 'Month and year are required' });
    }

    // Get tax settings
    const [taxSettings] = await db.query('SELECT * FROM tax_settings WHERE is_active = 1');

    // Get employees
    let empQuery = 'SELECT * FROM employees WHERE status = "active"';
    const empParams = [];
    if (employee_ids && employee_ids.length > 0) {
      empQuery += ` AND id IN (${employee_ids.map(() => '?').join(',')})`;
      empParams.push(...employee_ids);
    }
    const [employees] = await db.query(empQuery, empParams);

    if (!employees.length) {
      return res.status(404).json({ success: false, message: 'No active employees found' });
    }

    const generated = [], skipped = [];

    for (const emp of employees) {
      // Check if already generated
      const [existing] = await db.query(
        'SELECT id FROM payroll_records WHERE employee_id = ? AND month = ? AND year = ?',
        [emp.id, month, year]
      );
      if (existing.length) { skipped.push(emp.name); continue; }

      // Calculate allowances
      const hra = (emp.base_salary * parseFloat(emp.hra_percent || 40)) / 100;
      const da = (emp.base_salary * parseFloat(emp.da_percent || 20)) / 100;
      const ta = parseFloat(emp.ta_fixed || 1600);
      const ma = parseFloat(emp.ma_fixed || 1250);
      const grossSalary = emp.base_salary + hra + da + ta + ma;

      // Calculate taxes
      const taxes = calculateTax(grossSalary, taxSettings);
      const totalDeductions = taxes.pt + taxes.ss + taxes.it;
      const netSalary = grossSalary - totalDeductions;

      await db.query(
        `INSERT INTO payroll_records 
          (employee_id, month, year, base_salary, hra, da, ta, ma, gross_salary,
           pt_deduction, ss_deduction, it_deduction, total_deductions, net_salary)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [emp.id, month, year, emp.base_salary,
         Math.round(hra * 100) / 100,
         Math.round(da * 100) / 100,
         ta, ma,
         Math.round(grossSalary * 100) / 100,
         taxes.pt, taxes.ss, taxes.it,
         Math.round(totalDeductions * 100) / 100,
         Math.round(netSalary * 100) / 100]
      );
      generated.push(emp.name);
    }

    res.json({
      success: true,
      message: `Payroll generated for ${generated.length} employees`,
      generated,
      skipped
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH update payment status
router.patch('/:id/status', async (req, res) => {
  try {
    const { payment_status, payment_date } = req.body;
    await db.query(
      'UPDATE payroll_records SET payment_status = ?, payment_date = ? WHERE id = ?',
      [payment_status, payment_date || new Date().toISOString().split('T')[0], req.params.id]
    );
    res.json({ success: true, message: 'Payment status updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET payroll slip PDF
router.get('/:id/slip', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT pr.*, e.name, e.employee_id as emp_code, e.email, e.designation,
              e.bank_account, e.bank_name, e.pan_number, e.joining_date,
              d.name as department_name
       FROM payroll_records pr
       JOIN employees e ON pr.employee_id = e.id
       LEFT JOIN departments d ON e.department_id = d.id
       WHERE pr.id = ?`,
      [req.params.id]
    );

    if (!rows.length) return res.status(404).json({ success: false, message: 'Payroll record not found' });
    const p = rows[0];

    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const monthName = monthNames[p.month - 1];

    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=payslip_${p.emp_code}_${monthName}_${p.year}.pdf`);
    doc.pipe(res);

    // Header
    doc.rect(0, 0, 595, 80).fill('#1e293b');
    doc.fillColor('white').fontSize(22).font('Helvetica-Bold')
       .text(process.env.COMPANY_NAME || 'Company Name', 50, 20);
    doc.fontSize(10).font('Helvetica')
       .text(`Payslip for ${monthName} ${p.year}`, 50, 50);
    doc.text(`Generated: ${new Date().toLocaleDateString('en-IN')}`, 400, 50);

    // Employee Details
    doc.fillColor('#1e293b').fontSize(13).font('Helvetica-Bold')
       .text('Employee Details', 50, 100);
    doc.moveTo(50, 118).lineTo(545, 118).strokeColor('#e2e8f0').stroke();

    const leftCol = 50, rightCol = 300;
    let y = 130;
    const addRow = (label, value, x, yPos) => {
      doc.fontSize(9).font('Helvetica-Bold').fillColor('#64748b').text(label, x, yPos);
      doc.fontSize(10).font('Helvetica').fillColor('#1e293b').text(value || 'N/A', x, yPos + 14);
    };

    addRow('Employee ID', p.emp_code, leftCol, y);
    addRow('Name', p.name, rightCol, y);
    y += 40;
    addRow('Department', p.department_name, leftCol, y);
    addRow('Designation', p.designation, rightCol, y);
    y += 40;
    addRow('PAN Number', p.pan_number, leftCol, y);
    addRow('Bank Account', p.bank_account ? `${p.bank_name} - ${p.bank_account}` : 'N/A', rightCol, y);

    // Salary Breakdown
    y += 55;
    doc.fontSize(13).font('Helvetica-Bold').fillColor('#1e293b').text('Salary Breakdown', leftCol, y);
    doc.moveTo(50, y + 18).lineTo(545, y + 18).strokeColor('#e2e8f0').stroke();
    y += 28;

    // Table header
    doc.rect(50, y, 495, 24).fill('#f1f5f9');
    doc.fontSize(9).font('Helvetica-Bold').fillColor('#475569');
    doc.text('EARNINGS', 60, y + 7);
    doc.text('AMOUNT (₹)', 200, y + 7);
    doc.text('DEDUCTIONS', 310, y + 7);
    doc.text('AMOUNT (₹)', 460, y + 7);
    y += 30;

    const earnings = [
      ['Basic Salary', p.base_salary],
      ['HRA', p.hra],
      ['DA', p.da],
      ['Travel Allowance', p.ta],
      ['Medical Allowance', p.ma],
    ];
    if (p.other_allowances > 0) earnings.push(['Other Allowances', p.other_allowances]);

    const deductions = [
      ['Professional Tax', p.pt_deduction],
      ['Social Security', p.ss_deduction],
      ['Income Tax (TDS)', p.it_deduction],
    ];
    if (p.other_deductions > 0) deductions.push(['Other Deductions', p.other_deductions]);

    const maxRows = Math.max(earnings.length, deductions.length);
    for (let i = 0; i < maxRows; i++) {
      if (i % 2 === 0) doc.rect(50, y - 3, 495, 22).fill('#fafafa');
      doc.fillColor('#334155').fontSize(9).font('Helvetica');
      if (earnings[i]) {
        doc.text(earnings[i][0], 60, y + 2);
        doc.text(`₹ ${parseFloat(earnings[i][1]).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, 200, y + 2);
      }
      if (deductions[i]) {
        doc.text(deductions[i][0], 310, y + 2);
        doc.text(`₹ ${parseFloat(deductions[i][1]).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, 460, y + 2);
      }
      y += 22;
    }

    // Totals
    y += 5;
    doc.rect(50, y, 495, 28).fill('#e2e8f0');
    doc.fontSize(10).font('Helvetica-Bold').fillColor('#1e293b');
    doc.text('Gross Salary', 60, y + 8);
    doc.text(`₹ ${parseFloat(p.gross_salary).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, 200, y + 8);
    doc.text('Total Deductions', 310, y + 8);
    doc.text(`₹ ${parseFloat(p.total_deductions).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, 460, y + 8);
    y += 38;

    // Net Salary
    doc.rect(50, y, 495, 36).fill('#1e293b');
    doc.fillColor('white').fontSize(14).font('Helvetica-Bold')
       .text('NET SALARY (Take Home)', 60, y + 10);
    doc.text(`₹ ${parseFloat(p.net_salary).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, 380, y + 10);

    // Footer
    y += 60;
    doc.fontSize(9).fillColor('#94a3b8').font('Helvetica')
       .text('This is a computer generated payslip. No signature required.', 50, y, { align: 'center', width: 495 });

    doc.end();
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET monthly/annual report data
router.get('/reports/summary', async (req, res) => {
  try {
    const { year } = req.query;
    const reportYear = year || new Date().getFullYear();

    const [monthly] = await db.query(
      `SELECT month, 
              SUM(gross_salary) as total_gross,
              SUM(total_deductions) as total_deductions,
              SUM(net_salary) as total_net,
              COUNT(*) as employee_count
       FROM payroll_records 
       WHERE year = ? AND payment_status = 'paid'
       GROUP BY month ORDER BY month`,
      [reportYear]
    );

    const [deptSummary] = await db.query(
      `SELECT d.name as department, 
              SUM(pr.net_salary) as total_net,
              COUNT(DISTINCT pr.employee_id) as employee_count
       FROM payroll_records pr
       JOIN employees e ON pr.employee_id = e.id
       LEFT JOIN departments d ON e.department_id = d.id
       WHERE pr.year = ? AND pr.payment_status = 'paid'
       GROUP BY d.name`,
      [reportYear]
    );

    const [totals] = await db.query(
      `SELECT COUNT(DISTINCT employee_id) as total_employees,
              SUM(gross_salary) as annual_gross,
              SUM(total_deductions) as annual_deductions,
              SUM(net_salary) as annual_net
       FROM payroll_records 
       WHERE year = ? AND payment_status = 'paid'`,
      [reportYear]
    );

    res.json({
      success: true,
      data: {
        monthly,
        deptSummary,
        totals: totals[0],
        year: reportYear
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
