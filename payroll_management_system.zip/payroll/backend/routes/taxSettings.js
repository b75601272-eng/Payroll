const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET all tax settings
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM tax_settings ORDER BY tax_type, min_salary');
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST create tax setting
router.post('/', async (req, res) => {
  try {
    const { name, tax_type, rate, min_salary, max_salary, is_active } = req.body;
    if (!name || !tax_type || rate === undefined) {
      return res.status(400).json({ success: false, message: 'Name, tax_type, and rate are required' });
    }
    const [result] = await db.query(
      'INSERT INTO tax_settings (name, tax_type, rate, min_salary, max_salary, is_active) VALUES (?, ?, ?, ?, ?, ?)',
      [name, tax_type, rate, min_salary || 0, max_salary || null, is_active !== undefined ? is_active : 1]
    );
    res.status(201).json({ success: true, message: 'Tax setting created', data: { id: result.insertId } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT update tax setting
router.put('/:id', async (req, res) => {
  try {
    const { name, tax_type, rate, min_salary, max_salary, is_active } = req.body;
    await db.query(
      'UPDATE tax_settings SET name=?, tax_type=?, rate=?, min_salary=?, max_salary=?, is_active=? WHERE id=?',
      [name, tax_type, rate, min_salary || 0, max_salary || null, is_active, req.params.id]
    );
    res.json({ success: true, message: 'Tax setting updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE tax setting
router.delete('/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM tax_settings WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Tax setting deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
