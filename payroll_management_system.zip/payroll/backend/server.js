const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/employees', require('./routes/employees'));
app.use('/api/payroll', require('./routes/payroll'));
app.use('/api/departments', require('./routes/departments'));
app.use('/api/tax-settings', require('./routes/taxSettings'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Payroll API is running', timestamp: new Date().toISOString() });
});

// Dashboard stats
app.get('/api/dashboard', async (req, res) => {
  try {
    const db = require('./config/db');
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    const [[empStats]] = await db.query(
      'SELECT COUNT(*) as total, SUM(status="active") as active, SUM(status="inactive") as inactive FROM employees'
    );
    const [[payrollMonth]] = await db.query(
      `SELECT COUNT(*) as processed, SUM(net_salary) as total_net, 
              SUM(payment_status="paid") as paid, SUM(payment_status="pending") as pending
       FROM payroll_records WHERE month = ? AND year = ?`,
      [currentMonth, currentYear]
    );
    const [[deptCount]] = await db.query('SELECT COUNT(*) as total FROM departments');
    const [recentPayroll] = await db.query(
      `SELECT pr.id, e.name, e.employee_id as emp_code, pr.net_salary, 
              pr.payment_status, pr.month, pr.year
       FROM payroll_records pr JOIN employees e ON pr.employee_id = e.id
       ORDER BY pr.created_at DESC LIMIT 5`
    );

    res.json({
      success: true,
      data: {
        employees: empStats,
        currentMonthPayroll: payrollMonth,
        departments: deptCount.total,
        recentPayroll,
        currentMonth,
        currentYear
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🚀 Payroll Server running on http://localhost:${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}/api/dashboard`);
  console.log(`❤️  Health:    http://localhost:${PORT}/api/health\n`);
});
